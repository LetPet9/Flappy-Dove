let imgFundo, imgFly, imgHit;

function preload() {
    imgFundo = loadImage('./assets/bg.png');
    imgFly = loadImage('./assets/chickFly.png')
    imgHit = loadImage('./assets/chickGotHit.png')
}

function setup() {}

function draw() {}